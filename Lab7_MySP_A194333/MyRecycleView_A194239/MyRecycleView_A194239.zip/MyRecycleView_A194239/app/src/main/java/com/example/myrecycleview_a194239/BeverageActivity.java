package com.example.myrecycleview_a194239;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class BeverageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beverage);
    }
}